package org.minecraftnauja.p2p.provider.file.task;

/**
 * Task for uploading a file.
 */
public interface IUpload extends IFileTask {

}
