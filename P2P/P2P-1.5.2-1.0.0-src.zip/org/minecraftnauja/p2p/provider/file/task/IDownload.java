package org.minecraftnauja.p2p.provider.file.task;

/**
 * Task for downloading a file.
 */
public interface IDownload extends IFileTask {

}
