package org.minecraftnauja.p2p.provider.file.event;

import java.util.EventListener;

/**
 * Interface for {@code IFileProvider} listeners.
 */
public interface IFileListener extends IFileCallback, EventListener {

}
