package org.minecraftnauja.p2p.event;

/**
 * Adapter for the mod listeners.
 */
public class P2PAdapter implements P2PListener {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onServerStarting(ServerEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onServerStarted(ServerEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onServerShutdown(ServerEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onClientStarting(ClientEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onClientStarted(ClientEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onClientShutdown(ClientEvent event) {
	}

}
