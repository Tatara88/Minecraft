package org.minecraftnauja.p2p.peer;

import org.minecraftnauja.p2p.config.IClientConfig;

/**
 * Interface for clients.
 */
public interface IClient extends IPeer<IClientConfig> {

}
