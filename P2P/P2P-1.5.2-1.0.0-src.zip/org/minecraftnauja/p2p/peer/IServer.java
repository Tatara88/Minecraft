package org.minecraftnauja.p2p.peer;

import org.minecraftnauja.p2p.config.IServerConfig;

/**
 * Interface for servers.
 */
public interface IServer extends IPeer<IServerConfig> {

}
