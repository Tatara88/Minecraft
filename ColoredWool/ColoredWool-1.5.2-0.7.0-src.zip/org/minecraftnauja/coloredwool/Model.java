package org.minecraftnauja.coloredwool;

public enum Model {
	
	Flat

}
