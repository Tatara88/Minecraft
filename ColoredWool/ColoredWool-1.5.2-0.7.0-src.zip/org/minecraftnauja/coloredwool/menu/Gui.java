package org.minecraftnauja.coloredwool.menu;

public enum Gui {

	ColoredWool,
	PictureFactoryFurnace,
	PictureFactoryImage,
	ModelFactoryFurnace,
	ModelFactoryImage

}
