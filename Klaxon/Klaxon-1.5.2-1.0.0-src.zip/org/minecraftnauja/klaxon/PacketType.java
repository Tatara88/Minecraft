package org.minecraftnauja.klaxon;

public enum PacketType {
	
	PlayKlaxon, UploadedKlaxon, UpdateKlaxon

}
