package org.minecraftnauja.tomp2p.event;

/**
 * Adapter for peers listeners.
 */
public class PeerAdapter implements PeerListener {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onGet(GetEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onGetFailed(GetEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onPut(PutEvent event) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void onPutFailed(PutEvent event) {
	}

}
